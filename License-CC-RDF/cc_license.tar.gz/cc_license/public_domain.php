<?php

##################################################
##################################################

// PUBLIC DOMAIN DEDICATION
//
// This 'license' implies that no rights are
// reserved by the content producer. It is not a
// true license because it implies that ownership
// has been transferred to the public

##################################################
##################################################

require_once ('cc_license.php');

$pd_license = new cc_license ('Public Domain', 'Public Domain', 'http://creativecommons.org/licenses/publicdomain', '', 1, 1, 1, 0, 0, 0, 0, '');

return ($pd_license);

?>